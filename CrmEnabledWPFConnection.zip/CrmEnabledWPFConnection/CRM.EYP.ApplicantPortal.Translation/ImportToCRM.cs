﻿using OfficeOpenXml;
using OfficeOpenXml.Table;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;

namespace CrmEnabledWPFConnection
{
    public class ImportToCRM
    {
        public IOrganizationService _orgService { get; set; }
        //public ImportToCRM()
        //{ }

        public ImportToCRM(IOrganizationService service)
        {
            this._orgService = service;
        }

        public void ReadXLS(string FilePath)
        {
            List<CRMDataObject> importList = new List<CRMDataObject>();
            FileInfo existingFile = new FileInfo(FilePath);
            using (ExcelPackage package = new ExcelPackage(existingFile))
            {

                //get the first worksheet in the workbook
                ExcelWorksheet worksheet = package.Workbook.Worksheets[1];
                int colCount = worksheet.Dimension.End.Column;  //get Column Count
                int rowCount = worksheet.Dimension.End.Row;     //get row count
                for (int row = 1; row <= rowCount; row++)
                {
                    CRMDataObject x = new CRMDataObject();
                    //int col = 0;
                    x.GUID = ParseGuid(worksheet.Cells[row, 1].Value.ToString().Trim());
                    x.Name = worksheet.Cells[row, 2].Value.ToString().Trim();
                    x.NameIE = worksheet.Cells[row, 3].Value.ToString().Trim();
                    x.GUID_IE = ParseGuid(worksheet.Cells[row, 4].Value.ToString().Trim());
                    //Console.WriteLine(" Row:" + row + " column:" + col + " Value:" + worksheet.Cells[row, col].Value.ToString().Trim());

                    importList.Add(x);
                }
            }
        }

        public Guid ParseGuid(string stringGuid)
        {
            Guid newGuid = Guid.Parse(stringGuid);

            return newGuid;
        }

        public DataTable GetDataTableFromExcel(string path, bool hasHeader = true)
        {
            using (var pck = new OfficeOpenXml.ExcelPackage())
            {
                using (var stream = File.OpenRead(path))
                {
                    pck.Load(stream);
                }
                var ws = pck.Workbook.Worksheets[1];
                DataTable tbl = new DataTable();
                foreach (var firstRowCell in ws.Cells[1, 1, 1, ws.Dimension.End.Column])
                {
                    tbl.Columns.Add(hasHeader ? firstRowCell.Text : string.Format("Column {0}", firstRowCell.Start.Column));
                }
                var startRow = hasHeader ? 2 : 1;
                for (int rowNum = startRow; rowNum <= ws.Dimension.End.Row; rowNum++)
                {
                    var wsRow = ws.Cells[rowNum, 1, rowNum, ws.Dimension.End.Column];
                    DataRow row = tbl.Rows.Add();
                    foreach (var cell in wsRow)
                    {
                        row[cell.Start.Column - 1] = cell.Text;
                    }
                }
                return tbl;
            }
        }

        public void MainImportMethod(List<CRMDataObject> entityData)
        {
            ImportDataForCustomEntity(entityData, "eyp_applicationtype");
            ImportDataForCustomEntity(entityData, "eyp_applicationstage");
            ImportDataForCustomEntity(entityData, "eyp_childapplicantrelationshiptype");
            ImportDataForCustomEntity(entityData, "eyp_country");
            ImportDataForCustomEntity(entityData, "eyp_county");
            ImportDataForCustomEntity(entityData, "eyp_documenttype");
            ImportDataForCustomEntity(entityData, "eyp_educationstage");
            ImportDataForCustomEntity(entityData, "eyp_employmentstatus");
        }

        //public void ImportApplicationTypeEntity(IEnumerable<CRMDataObject> Data)
        //{
        //    foreach (var d in Data)
        //    {
        //        //switch (d.EntityName)
        //        //{
        //        //    case "":
        //        //    default:
        //        //        break;
        //        //}

        //        Entity targetEntity = new Entity(d.EntityName);
        //        targetEntity.Id = d.GUID;
        //        targetEntity["eyp_name_ie"] = d.NameIE;


        //        _orgService.Update(targetEntity);
        //    }
        //}

        public void ImportDataForCustomEntity(List<CRMDataObject> entityData, string entityName)
        {
            List<CRMDataObject> data = entityData.Where(d => d.EntityName == entityName).ToList();
            foreach (var d in data)
            {
                Entity targetEntity = new Entity(d.EntityName);
                targetEntity.Id = d.GUID;
                targetEntity["eyp_name_ie"] = d.NameIE;


                _orgService.Update(targetEntity);
            }
        }
    }
}
