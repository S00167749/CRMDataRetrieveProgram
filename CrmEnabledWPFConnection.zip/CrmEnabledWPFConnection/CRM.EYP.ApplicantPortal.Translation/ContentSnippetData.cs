﻿using Microsoft.Xrm.Sdk;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CrmEnabledWPFConnection
{
    public class ContentSnippetData
    {
        public string Value { get; set; }
        public EntityReference Language { get; set; }
        public Guid GUID { get; set; }
        public string Name { get; set; }
        public OptionSetValue Type { get; set; }

        public string EntityName { get; set; }

        public ContentSnippetData(
            string value, 
           EntityReference language, 
            Guid guid, OptionSetValue type, string name, string entityname)
        {
            this.Value = value;
            this.Language = language;
            this.GUID = guid;
            this.Type = type;
            this.Name = name;
            this.EntityName = entityname;
        }

        public ContentSnippetData()
        { }
    }
}
