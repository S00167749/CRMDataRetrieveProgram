﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CrmEnabledWPFConnection
{
    public class CRMDataObject
    {
        public string Name { get; set; }
        public Guid GUID { get; set; }

        public Guid GUID_IE { get; set; }

        public string EntityName { get; set; }

        public string NameIE { get; set; }

        public CRMDataObject(string entity, Guid guid, string name, string nameIE)
        {
            this.Name = name;
            this.GUID = guid;
            this.EntityName = entity;
            this.NameIE = nameIE;
        }

        public CRMDataObject(string entity, Guid guid, string name, string nameIE, Guid guid_ie)
        {
            this.Name = name;
            this.GUID = guid;
            this.EntityName = entity;
            this.NameIE = nameIE;
            this.GUID_IE = guid_ie;
        }

        public CRMDataObject()
        { }
    }
}
