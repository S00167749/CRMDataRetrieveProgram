﻿using CrmEnabledWPFConnection.LoginWindow;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.ComponentModel;
using OfficeOpenXml;
using OfficeOpenXml.Drawing;
using OfficeOpenXml.Style;
using System.IO;
using System.Data;
using Microsoft.VisualBasic.FileIO;

namespace CrmEnabledWPFConnection
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public IOrganizationService _orgService;
        DataTable dt = new DataTable();
        ImportToCRM ImportExcel;


        public MainWindow()
        {
            dt.Columns.Add(new DataColumn("GUID", typeof(Guid)));
            dt.Columns.Add(new DataColumn("Entity", typeof(string)));
            dt.Columns.Add(new DataColumn("Name", typeof(string)));
            dt.Columns.Add(new DataColumn("Name_IE", typeof(string)));
            dt.Columns.Add(new DataColumn("GUID_IE", typeof(Guid)));

            InitializeComponent();
        }

        /// <summary>
        /// Button to login to CRM and create a CrmService Client 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            #region Login Control
            // Establish the Login control
            CrmLogin ctrl = new CrmLogin();
            // Wire Event to login response. 
            ctrl.ConnectionToCrmCompleted += ctrl_ConnectionToCrmCompleted;
            // Show the dialog. 
            ctrl.ShowDialog();

            // Handel return. 
            if (ctrl.CrmConnectionMgr != null && ctrl.CrmConnectionMgr.CrmSvc != null && ctrl.CrmConnectionMgr.CrmSvc.IsReady)
            {
                MessageBox.Show("Good Connect. Version: " + ctrl.CrmConnectionMgr.CrmSvc.ConnectedOrgVersion.ToString() +
                    " Org: " + ctrl.CrmConnectionMgr.CrmSvc.ConnectedOrgUniqueName);

                _orgService = ctrl.CrmConnectionMgr.CrmSvc.OrganizationServiceProxy;
            }
            else
                MessageBox.Show("BadConnect");

            #endregion

            #region CRMServiceClient
            if (ctrl.CrmConnectionMgr != null && ctrl.CrmConnectionMgr.CrmSvc != null && ctrl.CrmConnectionMgr.CrmSvc.IsReady)
            {
                //                CrmServiceClient svcClient = ctrl.CrmConnectionMgr.CrmSvc;
                //                if (svcClient.IsReady)
                //                {
                //                    // Get data from CRM . 
                //                    string FetchXML =
                //                        @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                //                        <entity name='account'>
                //                            <attribute name='name' />
                //                            <attribute name='primarycontactid' />
                //                            <attribute name='telephone1' />
                //                            <attribute name='accountid' />
                //                            <order attribute='name' descending='false' />
                //                          </entity>
                //                        </fetch>";

                //                    var Result = svcClient.GetEntityDataByFetchSearchEC(FetchXML);
                //                    if (Result != null)
                //                    {
                //                        MessageBox.Show(string.Format("Found {0} records\nFirst Record name is {1}", Result.Entities.Count, Result.Entities.FirstOrDefault().GetAttributeValue<string>("name")));
                //                    }


                //                    // Core API using SDK OOTB 
                //                    CreateRequest req = new CreateRequest();
                //                    Entity accENt = new Entity("account");
                //                    accENt.Attributes.Add("name", "TESTFOO");
                //                    req.Target = accENt;
                //                    CreateResponse res = (CreateResponse)svcClient.OrganizationServiceProxy.Execute(req);
                //                    //CreateResponse res = (CreateResponse)svcClient.ExecuteCrmOrganizationRequest(req, "MyAccountCreate");
                //                    MessageBox.Show(res.id.ToString());



                //                    // Using Xrm.Tooling helpers. 
                //                    Dictionary<string, CrmDataTypeWrapper> newFields = new Dictionary<string, CrmDataTypeWrapper>();
                //                    // Create a new Record. - Account 
                //                    newFields.Add("name", new CrmDataTypeWrapper("CrudTestAccount", CrmFieldType.String));
                //                    Guid guAcctId = svcClient.CreateNewRecord("account", newFields);

                //                    MessageBox.Show(string.Format("New Record Created {0}", guAcctId));
                //}
            }
            #endregion


        }

        /// <summary>
        /// Raised when the login form process is completed.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ctrl_ConnectionToCrmCompleted(object sender, EventArgs e)
        {
            if (sender is CrmLogin)
            {
                this.Dispatcher.Invoke(() =>
                {
                    ((CrmLogin)sender).Close();
                });
            }
        }

        //retrieve all records of a entity 
        private void RetrieveApplicationTypeEntity()
        {
            QueryExpression qe = new QueryExpression("eyp_applicationtype");
            qe.ColumnSet.AllColumns = true;
            qe.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0);
            qe.Criteria.AddCondition("eyp_name", ConditionOperator.NotNull);

            EntityCollection eCollection = _orgService.RetrieveMultiple(qe); //it will retrieve the all attrributes
            List<CRMDataObject> applicationTypeList = new List<CRMDataObject>();
            if (eCollection != null)
            {
                foreach (var item in eCollection.Entities)
                {
                    applicationTypeList.Add(
                   new CRMDataObject("eyp_applicationtype",
                   item.GetAttributeValue<Guid>("eyp_applicationtypeid"), item.GetAttributeValue<string>("eyp_name"),
                   item.GetAttributeValue<string>("eyp_name_ie"))
                   );
                    MessageBox.Show(item.GetAttributeValue<string>("eyp_name"));
                }
            }

            CreateDataTable(applicationTypeList);
        }

        private void btnRetrieveData_Click(object sender, RoutedEventArgs e)
        {
            //progress bar is true
            pbStatus.IsIndeterminate = true;

            BackgroundWorker RetrieveApplicationStage = new BackgroundWorker();
            RetrieveApplicationStage.WorkerReportsProgress = true;
            RetrieveApplicationStage.DoWork += RetrieveApplicationStage_DoWork;
            RetrieveApplicationStage.RunWorkerCompleted += RetrieveApplicationStage_RunWorkerCompleted;
            RetrieveApplicationStage.RunWorkerAsync();

        }

        //progress bar not true. tell it to stop
        private void RetrieveApplicationStage_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            pbStatus.IsIndeterminate = false;
        }

        private void RetrieveApplicationStage_DoWork(object sender, DoWorkEventArgs e)
        {

            // Custom Entities retrieve
            RetrieveApplicationTypeEntity();
            RetrieveApplicationStageEntity();
            RetrieveChildApplicationRelationshipType();
            RetrieveCountryEntity();
            RetrieveCountyEntity();
            RetrieveDocumentTypeEntity();
            RetrieveEducationStageEntity();
            RetrieveEmploymentStatusEntity();
            RetrieveIACategorisationRuleEntity();
            RetrieveIACategorisationSourceEntity();
            RetrieveSystemMessageEntity();
            RetrieveContentSnippetEntity();
            RetrieveEntityFormMetadataEntity();
            RetrieveEntityFormMetadataLabelEntity();
            RetrieveEntityFormMetadataDescriptionEntity();
            // Portal Objects
            // 

            //ExporToExcel();

            ExporToExcel("C:/Users/amatin/Documents/Pobal/CRMDataExport.xlsx", dt);
        }

        //Write to Excel File
        private void ExporToExcel(string p_strPath, DataTable p_dsSrc)
        {
            FileInfo file = new FileInfo(p_strPath);

            using (ExcelPackage objExcelPackage = new ExcelPackage(file))
            {

                //Create the worksheet    
                ExcelWorksheet objWorksheet = objExcelPackage.Workbook.Worksheets.First(); //.Add("CRMDataExport");
                //Load the datatable into the sheet, starting from cell A1. Print the column names on row 1    
                objWorksheet.Cells["A1"].LoadFromDataTable(p_dsSrc, true);
                objWorksheet.Cells.Last().LoadFromDataTable(p_dsSrc, true);
                //objWorksheet.Cells.Style.Font.SetFromFont(new Font("Calibri", 10));
                objWorksheet.Cells.AutoFitColumns();
                //Format the header    
                using (ExcelRange objRange = objWorksheet.Cells["A1:XFD1"])
                {
                    objRange.Style.Font.Bold = true;
                    objRange.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                    objRange.Style.VerticalAlignment = ExcelVerticalAlignment.Center;
                    //objRange.Style.Fill.PatternType = ExcelFillStyle.Solid;
                    //objRange.Style.Fill.BackgroundColor.SetColor(Color.FromA#eaeaea);    
                };


                ////Write it back to the client
                //if (File.Exists(p_strPath))
                //    File.Delete(p_strPath);

                ////Create excel file on physical disk
                //FileStream objFileStrm = File.Create(p_strPath);
                //objFileStrm.Close();

                //Write content to excel file
                //AppendAllBytes(p_strPath, objExcelPackage.GetAsByteArray());

                //File.WriteAllBytes(p_strPath, objExcelPackage.GetAsByteArray());
                //FileSystem.WriteAllBytes(p_strPath, objExcelPackage.GetAsByteArray(), true);

                objExcelPackage.Save();

            };

        }

        //Convert list to a DataTable
        private void CreateDataTable(List<CRMDataObject> x)
        {

            DataRow dr;



            foreach (var i in x)
            {
                dr = dt.NewRow();

                dr[0] = i.GUID;
                dr[1] = i.EntityName;
                dr[2] = i.Name;
                dr[3] = i.NameIE;


                dt.Rows.Add(dr);
            }
            DataView dv = new DataView(dt);



            //ExporToExcel("C:/Users/amatin/Documents/Pobal/CRMDataExport.xlsx", dt);


        }

        private void CreateDataTableDoubleRecord(List<CRMDataObject> x)
        {
            DataRow dr;

            foreach (var i in x)
            {
                dr = dt.NewRow();

                dr[0] = i.GUID;
                dr[1] = i.EntityName;
                dr[2] = i.Name;
                dr[3] = i.NameIE;
                dr[4] = i.GUID_IE;


                dt.Rows.Add(dr);
            }
            DataView dv = new DataView(dt);

            //ExporToExcel("C:/Users/amatin/Documents/Pobal/CRMDataExport.xlsx", dt);

        }

        private void RetrieveApplicationStageEntity()
        {
            QueryExpression qe = new QueryExpression("eyp_applicationstage");
            qe.ColumnSet.AllColumns = true;
            qe.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0);
            qe.Criteria.AddCondition("eyp_name", ConditionOperator.NotNull);

            EntityCollection eCollection = _orgService.RetrieveMultiple(qe); //it will retrieve the all attrributes
            List<CRMDataObject> applicationTypeList = new List<CRMDataObject>();
            if (eCollection != null)
            {
                foreach (var item in eCollection.Entities)
                {
                    applicationTypeList.Add(
                   new CRMDataObject("eyp_applicationstage",
                   item.GetAttributeValue<Guid>("eyp_applicationstageid"), item.GetAttributeValue<string>("eyp_name"),
                   item.GetAttributeValue<string>("eyp_name_ie"))
                   );
                    MessageBox.Show(item.GetAttributeValue<string>("eyp_name"));
                }
            }

            CreateDataTable(applicationTypeList);
        }

        private void RetrieveChildApplicationRelationshipType()
        {
            QueryExpression qe = new QueryExpression("eyp_childapplicantrelationshiptype");
            qe.ColumnSet.AllColumns = true;
            qe.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0);
            qe.Criteria.AddCondition("eyp_name", ConditionOperator.NotNull);

            EntityCollection eCollection = _orgService.RetrieveMultiple(qe); //it will retrieve the all attrributes
            List<CRMDataObject> applicationTypeList = new List<CRMDataObject>();
            if (eCollection != null)
            {
                foreach (var item in eCollection.Entities)
                {
                    applicationTypeList.Add(
                   new CRMDataObject("eyp_childapplicantrelationshiptype",
                   item.GetAttributeValue<Guid>("eyp_childapplicantrelationshiptypeid"), item.GetAttributeValue<string>("eyp_name"),
                   item.GetAttributeValue<string>("eyp_name_ie"))
                   );
                    //MessageBox.Show(item.GetAttributeValue<string>("eyp_name"));
                }
            }

            CreateDataTable(applicationTypeList);
        }

        private void RetrieveCountryEntity()
        {
            QueryExpression qe = new QueryExpression("eyp_country");
            qe.ColumnSet.AllColumns = true;
            qe.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0);
            qe.Criteria.AddCondition("eyp_name", ConditionOperator.NotNull);

            EntityCollection eCollection = _orgService.RetrieveMultiple(qe); //it will retrieve the all attrributes
            List<CRMDataObject> applicationTypeList = new List<CRMDataObject>();
            if (eCollection != null)
            {
                foreach (var item in eCollection.Entities)
                {
                    applicationTypeList.Add(
                   new CRMDataObject(" eyp_country",
                   item.GetAttributeValue<Guid>("eyp_countryid"), item.GetAttributeValue<string>("eyp_name"),
                   item.GetAttributeValue<string>("eyp_name_ie"))
                   );
                    //MessageBox.Show(item.GetAttributeValue<string>("eyp_name"));
                }
            }

            CreateDataTable(applicationTypeList);
        }

        private void RetrieveCountyEntity()
        {
            QueryExpression qe = new QueryExpression("eyp_county");
            qe.ColumnSet.AllColumns = true;
            qe.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0);
            qe.Criteria.AddCondition("eyp_name", ConditionOperator.NotNull);

            EntityCollection eCollection = _orgService.RetrieveMultiple(qe); //it will retrieve the all attrributes
            List<CRMDataObject> applicationTypeList = new List<CRMDataObject>();
            if (eCollection != null)
            {
                foreach (var item in eCollection.Entities)
                {
                    applicationTypeList.Add(
                   new CRMDataObject(" eyp_county",
                   item.GetAttributeValue<Guid>("eyp_countyid"), item.GetAttributeValue<string>("eyp_name"),
                   item.GetAttributeValue<string>("eyp_name_ie"))
                   );
                    //MessageBox.Show(item.GetAttributeValue<string>("eyp_name"));
                }
            }

            CreateDataTable(applicationTypeList);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }


        private void RetrieveDocumentTypeEntity()
        {
            QueryExpression qe = new QueryExpression("eyp_documenttype");
            qe.ColumnSet.AllColumns = true;
            qe.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0);
            qe.Criteria.AddCondition("eyp_name", ConditionOperator.NotNull);

            EntityCollection eCollection = _orgService.RetrieveMultiple(qe); //it will retrieve the all attrributes
            List<CRMDataObject> applicationTypeList = new List<CRMDataObject>();
            if (eCollection != null)
            {
                foreach (var item in eCollection.Entities)
                {
                    applicationTypeList.Add(
                   new CRMDataObject("eyp_documenttype",
                   item.GetAttributeValue<Guid>("eyp_documenttypeid"), item.GetAttributeValue<string>("eyp_name"),
                   item.GetAttributeValue<string>("eyp_name_ie"))
                   );
                    //MessageBox.Show(item.GetAttributeValue<string>("eyp_name"));
                }
            }

            CreateDataTable(applicationTypeList);
        }


        private void RetrieveEducationStageEntity()
        {
            QueryExpression qe = new QueryExpression("eyp_educationstage");
            qe.ColumnSet.AllColumns = true;
            qe.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0);
            qe.Criteria.AddCondition("eyp_name", ConditionOperator.NotNull);

            EntityCollection eCollection = _orgService.RetrieveMultiple(qe); //it will retrieve the all attrributes
            List<CRMDataObject> applicationTypeList = new List<CRMDataObject>();
            if (eCollection != null)
            {
                foreach (var item in eCollection.Entities)
                {
                    applicationTypeList.Add(
                   new CRMDataObject("eyp_educationstage",
                   item.GetAttributeValue<Guid>("eyp_educationstageid"), item.GetAttributeValue<string>("eyp_name"),
                   item.GetAttributeValue<string>("eyp_name_ie"))
                   );
                    //MessageBox.Show(item.GetAttributeValue<string>("eyp_name"));
                }
            }

            CreateDataTable(applicationTypeList);

            List<CRMDataObject> applicationTypeList2 = new List<CRMDataObject>();
            if (eCollection != null)
            {
                foreach (var item in eCollection.Entities)
                {
                    applicationTypeList.Add(
                   new CRMDataObject("eyp_educationstage",
                   item.GetAttributeValue<Guid>("eyp_educationstageid"), item.GetAttributeValue<string>("eyp_standardhourssegmentmessage"),
                   item.GetAttributeValue<string>("eyp_standardhourssegmentmessage_ie"))
                   );
                    //MessageBox.Show(item.GetAttributeValue<string>("eyp_name"));
                }
            }

            CreateDataTable(applicationTypeList);

            List<CRMDataObject> applicationTypeList3 = new List<CRMDataObject>();
            if (eCollection != null)
            {
                foreach (var item in eCollection.Entities)
                {
                    applicationTypeList.Add(
                   new CRMDataObject("eyp_educationstage",
                   item.GetAttributeValue<Guid>("eyp_educationstageid"), item.GetAttributeValue<string>("eyp_enhancedhourssegmentmessage"),
                   item.GetAttributeValue<string>("eyp_enhancedhourssegmentmessage_ie"))
                   );
                    //MessageBox.Show(item.GetAttributeValue<string>("eyp_name"));
                }
            }

            CreateDataTable(applicationTypeList);
        }

        private void RetrieveEmploymentStatusEntity()
        {
            QueryExpression qe = new QueryExpression("eyp_employmentstatus");
            qe.ColumnSet.AllColumns = true;
            qe.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0);
            qe.Criteria.AddCondition("eyp_name", ConditionOperator.NotNull);

            EntityCollection eCollection = _orgService.RetrieveMultiple(qe); //it will retrieve the all attrributes
            List<CRMDataObject> applicationTypeList = new List<CRMDataObject>();
            if (eCollection != null)
            {
                foreach (var item in eCollection.Entities)
                {
                    applicationTypeList.Add(
                   new CRMDataObject("eyp_employmentstatus",
                   item.GetAttributeValue<Guid>("eyp_employmentstatusid"), item.GetAttributeValue<string>("eyp_name"),
                   item.GetAttributeValue<string>("eyp_name_ie"))
                   );
                    //MessageBox.Show(item.GetAttributeValue<string>("eyp_name"));
                }
            }

            CreateDataTable(applicationTypeList);
        }

        private void RetrieveIACategorisationRuleEntity()
        {
            QueryExpression qe = new QueryExpression("eyp_incomeassessmentcategorizationrule");
            qe.ColumnSet.AllColumns = true;
            qe.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0);
            qe.Criteria.AddCondition("eyp_categoryname", ConditionOperator.NotNull);

            EntityCollection eCollection = _orgService.RetrieveMultiple(qe); //it will retrieve the all attrributes
            List<CRMDataObject> applicationTypeList = new List<CRMDataObject>();
            if (eCollection != null)
            {
                foreach (var item in eCollection.Entities)
                {
                    applicationTypeList.Add(
                   new CRMDataObject("eyp_incomeassessmentcategorizationrule",
                   item.GetAttributeValue<Guid>("eyp_incomeassessmentcategorizationruleid"), item.GetAttributeValue<string>("eyp_categoryname"),
                   item.GetAttributeValue<string>("eyp_categoryname_ie"))
                   );
                    //MessageBox.Show(item.GetAttributeValue<string>("eyp_name"));
                }
            }

            CreateDataTable(applicationTypeList);
        }

        private void RetrieveIACategorisationSourceEntity()
        {
            QueryExpression qe = new QueryExpression("eyp_incomeassessmentcategorizationsource");
            qe.ColumnSet.AllColumns = true;
            qe.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0);
            qe.Criteria.AddCondition("eyp_displayname", ConditionOperator.NotNull);

            EntityCollection eCollection = _orgService.RetrieveMultiple(qe); //it will retrieve the all attrributes
            List<CRMDataObject> applicationTypeList = new List<CRMDataObject>();
            if (eCollection != null)
            {
                foreach (var item in eCollection.Entities)
                {
                    applicationTypeList.Add(
                   new CRMDataObject("eyp_incomeassessmentcategorizationsource",
                   item.GetAttributeValue<Guid>("eyp_incomeassessmentcategorizationsourceid"), item.GetAttributeValue<string>("eyp_displayname"),
                   item.GetAttributeValue<string>("eyp_displayname_ie"))
                   );
                    //MessageBox.Show(item.GetAttributeValue<string>("eyp_name"));
                }
            }

            CreateDataTable(applicationTypeList);
        }

        private void RetrieveSystemMessageEntity()
        {
            QueryExpression qe = new QueryExpression("eyp_systemmessages");
            qe.ColumnSet.AllColumns = true;
            qe.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0);
            qe.Criteria.AddCondition("eyp_message", ConditionOperator.NotNull);

            EntityCollection eCollection = _orgService.RetrieveMultiple(qe); //it will retrieve the all attrributes
            List<CRMDataObject> applicationTypeList = new List<CRMDataObject>();
            if (eCollection != null)
            {
                foreach (var item in eCollection.Entities)
                {
                    applicationTypeList.Add(
                   new CRMDataObject("eyp_systemmessages",
                   item.GetAttributeValue<Guid>("eyp_systemmessagesid"), item.GetAttributeValue<string>("eyp_message"),
                   item.GetAttributeValue<string>("eyp_message_ie"))
                   );
                    //MessageBox.Show(item.GetAttributeValue<string>("eyp_name"));
                }
            }

            CreateDataTable(applicationTypeList);
        }

        private void RetrieveContentSnippetEntity()
        {
            QueryExpression qe = new QueryExpression("adx_contentsnippet");
            qe.ColumnSet.AllColumns = true;
            qe.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0);
            qe.Criteria.AddCondition("adx_name", ConditionOperator.NotNull);
            //applicant portal referance id is hard coded in//D78574F9-20C3-4DCC-8D8D-85CF5B7AC141
            qe.Criteria.AddCondition("adx_websiteid", ConditionOperator.Equal, "D78574F9-20C3-4DCC-8D8D-85CF5B7AC141");
            qe.Criteria.AddCondition("adx_contentsnippetlanguageid", ConditionOperator.NotNull);

            EntityCollection eCollection = _orgService.RetrieveMultiple(qe); //it will retrieve the all attrributes
            List<ContentSnippetData> applicationTypeList = new List<ContentSnippetData>();
            if (eCollection != null)
            {
                foreach (var item in eCollection.Entities)
                {
                    applicationTypeList.Add(
                   new ContentSnippetData(
                       item.GetAttributeValue<string>("adx_value"),
                   item.GetAttributeValue<EntityReference>("adx_contentsnippetlanguageid"),
                   item.GetAttributeValue<Guid>("adx_contentsnippetid"),
                   item.GetAttributeValue<OptionSetValue>("adx_type"),
                   item.GetAttributeValue<string>("adx_name"), "adx_contentsnippet")
                   );
                    //MessageBox.Show(item.GetAttributeValue<string>("eyp_name"));
                }
            }
            FilterCodeSnippets(applicationTypeList);
            //CreateDataTable(applicationTypeList);
        }

        private void FilterCodeSnippets(List<ContentSnippetData> x)
        {
            List<CRMDataObject> filterList = new List<CRMDataObject>();

            if (x.Count % 2 != 0)
            {
                MessageBox.Show("Code snippets dont have an even number of receords!!");
            }

            List<ContentSnippetData> english = x.Where(c => c.Language.Id.ToString() == "506014c5-7864-e611-80d7-00155db4fa48").ToList();
            List<ContentSnippetData> irish = x.Where(c => c.Language.Id.ToString() == "78a96b25-10b1-e811-a824-005056a99671").ToList();

            foreach (ContentSnippetData snippetEN in english)
            {
                ContentSnippetData snippetIE = irish.Where(c => c.Name == snippetEN.Name).FirstOrDefault();
                //if (snippetIE is null)
                //    break;

                filterList.Add(new CRMDataObject(
                        snippetEN.EntityName, snippetEN.GUID, snippetEN.Value, snippetIE.Value, snippetIE.GUID));

            }


            //for (int i = 0; i < x.Count; i ++)
            //{
            //    for (int j = 0; j < codeSnippets.Count; j++)
            //    {
            //        if (x[i].Name == codeSnippets[j].Name)
            //        {
            //            filterList.Add(new CRMDataObject(
            //            x[i].EntityName, x[i].GUID, x[i].Value, codeSnippets[j].Value, codeSnippets[j].GUID));
            //            //.Type.ToStrin() // foroptionsetvalue
            //            x.Remove(x[i]);
            //        }
            //    }         
            //}

            CreateDataTableDoubleRecord(filterList);


        }

        private void RetrieveEntityFormMetadataEntity()
        {
            OptionSetValue types = new OptionSetValue();
            types.Value = 100000003;
            QueryExpression qe = new QueryExpression("adx_entityformmetadata");
            qe.ColumnSet.AllColumns = true;
            qe.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0);
            qe.Criteria.AddCondition("adx_subgrid_name", ConditionOperator.NotNull);
            qe.Criteria.AddCondition("adx_type", ConditionOperator.Equal, types.Value);

            EntityCollection eCollection = _orgService.RetrieveMultiple(qe); //it will retrieve the all attrributes
            List<CRMDataObject> applicationTypeList = new List<CRMDataObject>();
            if (eCollection != null)
            {
                foreach (var item in eCollection.Entities)
                {
                    applicationTypeList.Add(
                   new CRMDataObject("adx_entityformmetadata",
                   item.GetAttributeValue<Guid>("adx_entityformmetadataid"), item.GetAttributeValue<string>("adx_subgrid_settings"), "")
                   //item.GetAttributeValue<string>("eyp_message_ie"))
                   );
                    //MessageBox.Show(item.GetAttributeValue<string>("eyp_name"));
                }
            }

            CreateDataTable(applicationTypeList);
        }
        private void RetrieveEntityFormMetadataLabelEntity()
        {

            QueryExpression qe = new QueryExpression("adx_entityformmetadata");
            qe.ColumnSet.AllColumns = true;
            qe.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0);
            qe.Criteria.AddCondition("adx_label", ConditionOperator.NotNull);

            EntityCollection eCollection = _orgService.RetrieveMultiple(qe); //it will retrieve the all attrributes
            List<CRMDataObject> applicationTypeList = new List<CRMDataObject>();
            if (eCollection != null)
            {
                foreach (var item in eCollection.Entities)
                {
                    applicationTypeList.Add(
                   new CRMDataObject("adx_entityformmetadata",
                   item.GetAttributeValue<Guid>("adx_entityformmetadataid"), item.GetAttributeValue<string>("adx_label"), "")
                   //item.GetAttributeValue<string>("eyp_message_ie"))
                   );
                    //MessageBox.Show(item.GetAttributeValue<string>("eyp_name"));
                }
            }

            CreateDataTable(applicationTypeList);
        }
        private void RetrieveEntityFormMetadataDescriptionEntity()
        {

            QueryExpression qe = new QueryExpression("adx_entityformmetadata");
            qe.ColumnSet.AllColumns = true;
            qe.Criteria.AddCondition("statecode", ConditionOperator.Equal, 0);
            qe.Criteria.AddCondition("adx_description", ConditionOperator.NotNull);

            EntityCollection eCollection = _orgService.RetrieveMultiple(qe); //it will retrieve the all attrributes
            List<CRMDataObject> applicationTypeList = new List<CRMDataObject>();
            if (eCollection != null)
            {
                foreach (var item in eCollection.Entities)
                {
                    applicationTypeList.Add(
                   new CRMDataObject("adx_entityformmetadata",
                   item.GetAttributeValue<Guid>("adx_entityformmetadataid"), item.GetAttributeValue<string>("adx_description"), "")
                   //item.GetAttributeValue<string>("eyp_message_ie"))
                   );
                    //MessageBox.Show(item.GetAttributeValue<string>("eyp_name"));
                }
            }

            CreateDataTable(applicationTypeList);
        }

        private void btnImportData_Click(object sender, RoutedEventArgs e)
        {

            //x.ReadXLS("C:/Users/amatin/Documents/Pobal/CRMDataExport.xlsx");
            ImportExcel = new ImportToCRM(_orgService);

            DataTable table = ImportExcel.GetDataTableFromExcel("C:/Users/amatin/Documents/Pobal/CRMDataExport.xlsx");
            ConvertDataTableToList(table);
        }

        private void ConvertDataTableToList(DataTable dt)
        {
            List<CRMDataObject> EntityDataList = new List<CRMDataObject>();
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                CRMDataObject entity = new CRMDataObject();
                entity.GUID = ImportExcel.ParseGuid(dt.Rows[i]["GUID"].ToString());
                entity.Name = dt.Rows[i]["Name"].ToString();

                string guid_ie = dt.Rows[i]["GUID_IE"].ToString();
                if (guid_ie != null && guid_ie != "")
                {
                    entity.GUID_IE = ImportExcel.ParseGuid(guid_ie);
                }
                entity.EntityName = dt.Rows[i]["Entity"].ToString();
                entity.NameIE = dt.Rows[i]["Name_IE"].ToString();
                EntityDataList.Add(entity);
            }

            ImportExcel.MainImportMethod(EntityDataList);

            DataGrid1.ItemsSource = EntityDataList;
        }
    }
}
